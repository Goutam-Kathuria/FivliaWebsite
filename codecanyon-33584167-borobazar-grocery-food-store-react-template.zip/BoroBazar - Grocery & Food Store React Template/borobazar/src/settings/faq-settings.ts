export const faq = [
  {
    id: 1,
    title: 'faq-one-title',
    content: 'faq-one-content',
  },
  {
    id: 2,
    title: 'faq-two-title',
    content: 'faq-two-content',
  },
  {
    id: 3,
    title: 'faq-three-title',
    content: 'faq-three-content',
  },
  {
    id: 4,
    title: 'faq-four-title',
    content: 'faq-four-content',
  },
];
